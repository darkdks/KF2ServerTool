Instalation English
For existing server
- Extract the all the files into zip to server folder (same folder that you have a .bat to start the server).

For new server installation
- Put the tool in the same folder that you wanna install the server
- Open the tool and follow the steps


Instala��o - Portugu�s
Para server j� existente:
- Extraia todo os arquivos do zip para pasta do servidor (a mesma basta que tem um .bat para iniciar o servidor).
- Para mudar para portugu�s, edite o arquivo KF2ServerTool.ini e modifique a linha Language=EG para Language=BR.

Para uma nova instala��o de servidor:
- Coloque a ferramenta na mesma pasta em que voc� quer instalar o servidor
- Abra a ferramenta


